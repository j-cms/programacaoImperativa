/* Programa para criptografar e descriptografar
o primeiro nome e o sobrenome de uma pessoa, sendo que
ambos podem ser nomes compostos */

#include <stdio.h>

const char LF = 10; 



  

int main()
{
    const int MAX_LETRAS = 9;
    const int TAMANHO_BUFFER = MAX_LETRAS + 1;
    const int PRIMEIRO_NOME_SHIFT = 1;
    const int SOBRENOME_SHIFT = 2;
    char primeiro_nome[TAMANHO_BUFFER];
    char sobrenome[TAMANHO_BUFFER];
    int i, nao_fim_linha;
    int verifica(char,char);
    char crip(char, char, int);
    char decrip(char, char, int);


    printf("Digite o primeiro nome e tecle ENTER: ");
    i = 0;
    nao_fim_linha = 1;
    while (i < MAX_LETRAS && nao_fim_linha)
    {
        char c = getchar();
        if (c == LF) 
            nao_fim_linha = 0;
        else
        {
            primeiro_nome[i] = c;
            i++;
        }
    }
    primeiro_nome[i] = '\0'; 
    while (nao_fim_linha) 
    {
        char c = getchar();
        nao_fim_linha =  verifica(c, LF);
    }
    printf("Primeiro nome armazenado: %s\n", primeiro_nome);


    printf("Digite o sobrenome e tecle ENTER: ");
    i = 0;
    nao_fim_linha = 1;
    while (i < MAX_LETRAS && nao_fim_linha)
    {
        char c = getchar();
        if (c == LF)
            nao_fim_linha = 0;
        else
        {
            sobrenome[i] = c;
            i++;
        }
    }
    sobrenome[i] = '\0'; 
    while (nao_fim_linha) 
    {
        char c = getchar();
        nao_fim_linha =  verifica(c, LF);
    }
    printf("Sobrenome armazenado: %s\n", sobrenome);


    char primeiro_nome_criptografado[TAMANHO_BUFFER];
    i = 0;
    while(primeiro_nome[i]){
      primeiro_nome_criptografado[i] = crip(primeiro_nome_criptografado[i],primeiro_nome[i], PRIMEIRO_NOME_SHIFT);
      i++;
      primeiro_nome_criptografado[i]='\0';
    }

    
  
    char sobrenome_criptografado[TAMANHO_BUFFER];
    i = 0;
    while (sobrenome[i]) 
    {
        sobrenome_criptografado[i] = crip(sobrenome_criptografado[i], sobrenome[i],SOBRENOME_SHIFT); 
        i++;
    } 
    sobrenome_criptografado[i] = '\0'; 
    
  
    printf("Primeiro nome criptografado: %s\n", primeiro_nome_criptografado);
    printf("Sobrenome criptografado: %s\n", sobrenome_criptografado);


    char primeiro_nome_descriptografado[TAMANHO_BUFFER];
    i = 0;
    while (primeiro_nome_criptografado[i]) 
    {
        primeiro_nome_descriptografado[i] = decrip(primeiro_nome_descriptografado[i], primeiro_nome_criptografado[i], PRIMEIRO_NOME_SHIFT);
        i++;
    }
    primeiro_nome_descriptografado[i] = '\0'; 
    

    char sobrenome_descriptografado[TAMANHO_BUFFER];
    i = 0;
    while (sobrenome_criptografado[i])
    {
        sobrenome_descriptografado[i] = decrip(sobrenome_descriptografado[i], sobrenome_criptografado[i], SOBRENOME_SHIFT);
        i++;
    }
    sobrenome_descriptografado[i] = '\0'; 


    printf("Primeiro nome descriptografado: %s\n", primeiro_nome_descriptografado);
    printf("Sobrenome descriptografado: %s\n", sobrenome_descriptografado);

    return 0;
}
int verifica(char x, char y){
  if (x == y){
  return 0;
  }
}

char crip(char a, char b, int c){
    a = b + c;
    return a;
}
char decrip(char a, char b, int c){
    a = b - c;
    return a;
}

