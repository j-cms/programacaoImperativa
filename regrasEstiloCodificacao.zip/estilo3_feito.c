#include <stdio.h>

int main()
{
    float a1, a2; // operandos
    double RESULTADO = 0; // resultado da operação
    char op_char; // operador na forma de caracter
    puts("Digite o primeiro operando: ");
    scanf("%f", &a1);
    puts("Digite o segundo operando: ");
    scanf("%f", &a2);
    getchar();
    puts("Digite um operador (+, -, *, /): ");
    op_char = getchar();

    switch (op_char)
    {
    case '+':
        RESULTADO = a1+ a2;
        break;

    case '-':
        RESULTADO = a1 - a2;
        break;

    case '*':
        RESULTADO = a1* a2;
        break;

    case '/':
        RESULTADO = a1/ a2;
        break;
    
    default:
        puts("Operador inválido");
        break;
    };

    printf("Resultado = %.2f\n", RESULTADO);
    return 0;
}