#include <stdio.h>

// Função para calcular o salário líquido do funcionário:
int calcular_salario_liquido(salario_liquido, total_descontos, salario_bruto)
{
  return salario_liquido = salario_bruto - total_descontos;
}

// Função principal:
int main()
{
    double salario_bruto;
    double total_descontos;
    double salario_liquido;
    printf("Digite o salário bruto:");
    scanf("%lf", &salario_bruto);
    puts("Digite o total de descontos:");
    scanf("%lf", &total_descontos);
    salario_liquido = calcular_salario_liquido(salario_liquido, total_descontos, salario_bruto); // chamada da função
    printf("O salário líquido é %.2f\n", salario_liquido);
    return 0;
}