#include <stdio.h>2


enum MESES_e {janeiro, fevereiro, março, abril, maio, junho, julho, agosto, setembro, outubro, novembro, dezembro};

enum DIA_DA_SEMANA_e { segunda, terca, quarta,quinta, sexta, sabado, domingo};


char* meses[] = { "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro" };

char* dias_da_semana[] = { "Segunda-feira", "Terça-feira", "Quarta-feira",
    "Quinta-feira", "Sexta-feira", "Sábado", "Domingo" };

int main()
{
    // SELEÇÃO DO MÊS DO ANO:
    puts("Meses do ano: ");
    
    for (int m = janeiro; m <= dezembro; m++)
    {
        printf("\t(%2d) %s\n", m, meses[m]);
    }

    int mes_selecionado;
    puts("Selecione um mês pelo seu número: ");
    scanf("%d", &mes_selecionado);
    printf("Mês selecionado: %s\n", meses[mes_selecionado]);

    // SELEÇÃO DO DIA DA SEMANA:
    putchar('\n');
    puts("Dias da semana: ");

    for (int d = segunda; d <= domingo; d++)
    {
        printf("\t(%2d) %s\n", d, dias_da_semana[d]);
    }

    int dia_selecionado;
    puts("Selecione um dia pelo seu número: ");
    scanf("%d", &dia_selecionado);
    printf("Dia selecionado: %s\n", dias_da_semana[dia_selecionado]);

    // TOMADA DE DECISÃO:
    putchar('\n');

    if (mes_selecionado == janeiro || dia_selecionado == domingo)
    {
        puts("Descansar!\n");
    }
    else
    {
        puts("Trabalhar!\n");
    }

    return 0;
}