#include <stdio.h>

#define MAX_LETRAS 3

int main()
{
    char letras[MAX_LETRAS];

    printf("Digite %d letras: \n",MAX_LETRAS);

    for (int i = 0; i < MAX_LETRAS; i++)
    {
        printf("letra %d: ", i+1);
        letras[i] = getchar();
        getchar(); // skip the ENTER char
    }

    printf("As %d letras digitadas foram:", MAX_LETRAS);

    int i = 0;
    while (i < MAX_LETRAS)  
    {
        putchar(letras[i]);
        i++;
    }
    putchar('\n');

    puts("Digite uma sequência de, no máximo, 9 letras:");
    scanf("%s", letras);
    printf("Sequência digitada: %s", letras);
    putchar('\n');
}